//using System;

//namespace MigraDoc.DocumentObjectModel
//{
//  /// <summary>
//  /// Defines the predefined style names.
//  /// </summary>
//  public class StyleNames
//  {
//    public const string DefaultParagraphFont = "DefaultParagraphFont";
//    public const string Normal = "Normal";
//    public const string Heading1 = "Heading1";
//    public const string Heading2 = "Heading2";
//    public const string Heading3 = "Heading3";
//    public const string Heading4 = "Heading4";
//    public const string Heading5 = "Heading5";
//    public const string Heading6 = "Heading6";
//    public const string Heading7 = "Heading7";
//    public const string Heading8 = "Heading8";
//    public const string Heading9 = "Heading9";
//    public const string Footnote = "Footnote";
//    public const string Header = "Header";
//    public const string Footer = "Footer";
//    public const string Hyperlink = "Hyperlink";
//    public const string InvalidStyleName = "InvalidStyleName";
//  }
//}
